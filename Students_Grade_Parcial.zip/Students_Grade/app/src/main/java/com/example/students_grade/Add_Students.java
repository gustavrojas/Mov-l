package com.example.students_grade;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Add_Students extends AppCompatActivity {

    private TextView ID, Nombre, Apellido, Nota1, Nota2, Nota3;
    private ArrayList<students> Students;
    private Resources Resources;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_students);

        ID = (TextView)findViewById(R.id.TxtID);
        Nombre = (TextView)findViewById(R.id.TxtNombre);
        Apellido = (TextView)findViewById(R.id.TxtApellido);
        Nota1 = (TextView)findViewById(R.id.TxtNota1);
        Nota2 = (TextView)findViewById(R.id.TxtNota2);
        Nota3 = (TextView)findViewById(R.id.TxtNota3);
        Resources = this.getResources();
        Students = Data.Get();
    }

    public void Save (View view){
        String IDV,IDE, NombreV, ApellidoV;
        float Nota1V, Nota2V, Nota3V;
        IDV = ID.getText().toString();
        IDE = ID.getText().toString();
        NombreV = Nombre.getText().toString();
        ApellidoV = Apellido.getText().toString();
        Nota1V = Float.parseFloat(Nota1.getText().toString());
        Nota2V = Float.parseFloat(Nota2.getText().toString());
        Nota3V = Float.parseFloat(Nota3.getText().toString());
        students a = new students(IDV, IDE, NombreV, ApellidoV, Nota1V, Nota2V, Nota3V);
        a.SaveStudent();
        Toast.makeText(this, R.string.add, Toast.LENGTH_LONG).show();
    }
}
