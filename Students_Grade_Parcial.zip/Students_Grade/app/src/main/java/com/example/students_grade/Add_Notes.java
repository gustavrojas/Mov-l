package com.example.students_grade;

import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Add_Notes extends AppCompatActivity {
    private Intent In;
    private ListView LV;
    private Resources Resources;
    private ArrayList<String> ListaB;
    private ArrayList<students> students;
    private TextView NoResult;
    private Method M;
    private float NotaFinal;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_notes);

        LV =  (ListView)findViewById(R.id.List2);
        students = Data.Get();
        ListaB = new ArrayList<String>();
        NoResult = (TextView)findViewById(R.id.TxtNoResult);

        NoResult.setVisibility(View.VISIBLE);

        if (students.size() > 0){
            LV.setVisibility(View.VISIBLE);
            NoResult.setVisibility(View.INVISIBLE);

            for (int i = 0; i< students.size(); i++){

                NotaFinal = M.calculate(students.get(i).getNota1(),students.get(i).getNota2(), students.get(i).getNota3());
                students.get(i).setNotaFinal(NotaFinal);

                ListaB.add(students.get(i).getNombre()+ " " +students.get(i).getApellido()+ "\n Nota final: "+ students.get(i).getNotaFinal());
            }
        }

    }
}
