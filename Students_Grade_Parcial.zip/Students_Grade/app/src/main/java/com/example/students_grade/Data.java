package com.example.students_grade;

import java.util.ArrayList;

public class Data {

    private static ArrayList<students> Student = new ArrayList<>();
    public static void Save (students a){ Student.add(a);}
    public static ArrayList<students> Get(){return Student;}

}
