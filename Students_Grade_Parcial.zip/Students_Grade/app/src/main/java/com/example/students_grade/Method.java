package com.example.students_grade;

public class Method {

    public static float calculate (float nota1, float nota2, float nota3 ){
        float notaFinal = 0;
        notaFinal = (nota1 + nota2 + nota3)/3;
        return notaFinal;
    }

}
