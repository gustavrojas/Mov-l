package com.example.students_grade;



public class students {
    private String ID, IDE;
    private String Nombre;
    private String Apellido;
    private float Nota1, Nota2, Nota3, NotaFinal;

    public students(String ID, String ide, String nombre, String apellido, float nota1, float nota2, float nota3) {
        this.ID = ID;
        IDE = ide;
        Nombre = nombre;
        Apellido = apellido;
        Nota1 = nota1;
        Nota2 = nota2;
        Nota3 = nota3;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        Nombre = nombre;
    }

    public String getApellido() {
        return Apellido;
    }

    public void setApellido(String apellido) {
        Apellido = apellido;
    }

    public float getNota1() {
        return Nota1;
    }

    public void setNota1(float nota1) {
        Nota1 = nota1;
    }

    public float getNota2() {
        return Nota2;
    }

    public void setNota2(float nota2) {
        Nota2 = nota2;
    }

    public float getNota3() {
        return Nota3;
    }

    public void setNota3(float nota3) {
        Nota3 = nota3;
    }

    public float getNotaFinal() {
        return NotaFinal;
    }

    public void setNotaFinal(float notaFinal) {
        NotaFinal = notaFinal;
    }

    public String getIDE() {
        return IDE;
    }

    public void setIDE(String IDE) {
        this.IDE = IDE;
    }

    public void SaveStudent () {
        Data.Save(this);
    }
}
