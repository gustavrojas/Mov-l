package com.example.schudulecontac;

import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CreateJewel extends AppCompatActivity {
    private Spinner Tipo, Material, Piedra;
    private Resources Resources;
    private CheckBox Marcar;
    private ArrayList<Jewel> jewels;
    private ArrayAdapter<String> AdapterT, AdapterM, AdapterP;
    private String[] Tipos, Materiales, Piedras;
    private TextView Mark;
    private int Precio;
    private  Method M;

    @Override
    protected void onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.create_jewel);

        Tipo = (Spinner)findViewById(R.id.Tipo);
        Material = (Spinner)findViewById(R.id.Material);
        Piedra = (Spinner)findViewById(R.id.Piedra);
        Marcar = (CheckBox)findViewById(R.id.MarkJewel);
        Mark =(TextView)findViewById(R.id.TxtMark);
        Tipos = getResources().getStringArray(R.array.Tipo);
        Materiales = getResources().getStringArray(R.array.Material);
        Piedras = getResources().getStringArray(R.array.Piedra);

        AdapterT = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Tipos);
        AdapterM = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Materiales);
        AdapterP = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Piedras);

        Tipo.setAdapter(AdapterT);
        Material.setAdapter(AdapterM);
        Piedra.setAdapter(AdapterP);

        Resources = this.getResources();
        jewels = Data.Get();


    }

    public void Save(View view) {
        String ID, TipoV, MaterialV, PiedraV, MarcaV;
        ID = (jewels.size() + 1) + "";
        TipoV = Tipo.getSelectedItem().toString();
        MaterialV = Material.getSelectedItem().toString();
        PiedraV = Piedra.getSelectedItem().toString();
        MarcaV = Mark.getText().toString();
        Precio = M.Costo(TipoV, MaterialV, PiedraV);

        if (!MarcaV.isEmpty() && Marcar.isChecked() == false) {
            Toast.makeText(this, R.string.not_done, Toast.LENGTH_LONG).show();
        } else {
            if (MarcaV.isEmpty() && Marcar.isChecked()){
                Toast.makeText(this, R.string.warning, Toast.LENGTH_SHORT).show();
            } else {
                Jewel J = new Jewel(ID, TipoV, MaterialV, PiedraV, MarcaV, Precio);
                J.SaveJewel();
                Toast.makeText(this, R.string.done, Toast.LENGTH_LONG).show();
            }
        }

    }



    }


