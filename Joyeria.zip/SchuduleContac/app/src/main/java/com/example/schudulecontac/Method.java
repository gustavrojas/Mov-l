package com.example.schudulecontac;

public class Method {

    public static int Costo (String Tipo, String Material, String Piedra){
        int Total=0;
            if (Tipo.equals("Bracelet") || Tipo.equals("Pulsera")){
                switch (Material){
                    case "Silver":
                        Total = Total + 50000;
                        break;
                    case "Plata":
                        Total = Total + 50000;
                        break;
                    case "Steel":
                        Total = Total + 30000;
                        break;
                    case "Acero":
                        Total = Total + 30000;
                        break;
                    case "Gold":
                        Total = Total + 90000;
                        break;
                    case "Oro":
                        Total = Total + 90000;
                        break;
                }
            }

            if (Tipo.equals("Necklace") || Tipo.equals("Cadena")){
                switch (Material){
                    case "Silver":
                        Total = Total + 100000;
                        break;
                    case "Plata":
                        Total = Total + 100000;
                        break;
                    case "Steel":
                        Total = Total + 50000;
                        break;
                    case "Acero":
                        Total = Total + 50000;
                        break;
                    case "Gold":
                        Total = Total + 150000;
                        break;
                    case "Oro":
                        Total = Total + 150000;
                        break;
                }
            }

            switch (Piedra){
                case "Ruby":
                    Total = Total + 190000;
                    break;
                case "Rubí":
                    Total = Total + 190000;
                    break;
                case "Emerald":
                    Total = Total + 180000;
                    break;
                case "Esmeralda":
                    Total = Total + 180000;
                    break;
                case "Quarz":
                    Total = Total + 150000;
                    break;
                case "Quarzo":
                    Total = Total + 150000;
                    break;
            }

        return Total;
    }
}
