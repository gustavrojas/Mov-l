package com.example.schudulecontac;

import java.util.ArrayList;

public class Data {

    private static ArrayList<Jewel> jewels = new ArrayList<>();
    public static void Save (Jewel c){ jewels.add(c);}
    public static ArrayList<Jewel> Get(){return jewels;}

}
