package com.example.jewelry_store;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class OrderList extends AppCompatActivity {

    private ListView LV;
    private ArrayList<Jewel> Jewels;
    private ArrayList<String> OrdersList;
    private Intent In;
    private TextView TxtNoResults;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.order_lists);

        LV=(ListView)findViewById(R.id.LVorders);

        TxtNoResults = (TextView)findViewById(R.id.TxtNoResults);
        Jewels = Data.Get();
        OrdersList = new ArrayList<String>();

        TxtNoResults.setVisibility(View.VISIBLE);
        LV.setVisibility(View.INVISIBLE);



        if (Jewels.size() > 0){
            LV.setVisibility(View.VISIBLE);
            TxtNoResults.setVisibility(View.INVISIBLE);

            for (int i = 0; i < Jewels.size() ; i++){
                OrdersList.add(Jewels.get(i).getTipJ() + " " + Jewels.get(i).getMatJ()+" "+ Jewels.get(i).getPieJ());
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, OrdersList);
        LV.setAdapter(adapter);



    }

}
