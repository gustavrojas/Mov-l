package com.example.jewelry_store;

import java.util.ArrayList;

public class Data {
    private static ArrayList<Jewel> Jewels = new ArrayList<>();
    public static void Save(Jewel j){Jewels.add(j);}
    public static ArrayList<Jewel> Get(){return Jewels;}
}
