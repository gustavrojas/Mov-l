package com.example.jewelry_store;

public class Jewel {

    private String TipJ;
    private String MatJ;
    private String PieJ;

    public Jewel(String tipJ, String matJ, String pieJ) {

        TipJ = tipJ;
        MatJ = matJ;
        PieJ = pieJ;
    }



    public String getTipJ() {
        return TipJ;
    }

    public void setTipJ(String tipJ) {
        TipJ = tipJ;
    }

    public String getMatJ() {
        return MatJ;
    }

    public void setMatJ(String matJ) {
        MatJ = matJ;
    }

    public String getPieJ() {
        return PieJ;
    }

    public void setPieJ(String pieJ) {
        PieJ = pieJ;
    }
}
