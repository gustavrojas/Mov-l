package com.example.jewelry_store;

import android.content.res.Resources;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.widget.Spinner;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Date;

public class CreateJewel extends AppCompatActivity {

    private Spinner clase, material, rock;
    private android.content.res.Resources Resources;
    private ArrayList<Jewel> Jewels;


    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_jewel);

        clase = (Spinner)findViewById(R.id.spClase);
        material = (Spinner)findViewById(R.id.spMat);
        rock= (Spinner)findViewById(R.id.spRock);


        Resources = this.getResources();
        Jewels = Data.Get ();
    }
}
